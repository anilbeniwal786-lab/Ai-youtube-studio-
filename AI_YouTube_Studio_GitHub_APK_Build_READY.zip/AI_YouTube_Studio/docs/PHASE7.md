# Phase 7

Phase 7 turns the Phase 6 scaffold into a more complete publishing workflow:

- AI thumbnail generation with GPT-Image-2 when `MOCK_MODE=false`.
- Thumbnail preview endpoint and automatic thumbnail assignment after YouTube upload.
- Configurable YouTube privacy and category fields.
- Better OAuth/token handling remains server-side; never put client secrets or API keys in the APK.
- Health endpoint reports OpenAI and YouTube credential readiness.
- Existing 9:16 / 16:9 rendering, Hindi TTS, scene planning and optional image-to-video adapter remain available.

## Run

```bash
cd backend
cp .env.example .env
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

For real generation set `MOCK_MODE=false` and provide `OPENAI_API_KEY`. For YouTube upload, create OAuth credentials in Google Cloud, enable YouTube Data API v3, and place the client JSON at the configured path. The upload scope is `youtube.upload`.

Google's current documentation recommends OAuth 2.0 for user authorization; installed-app loopback redirects are deprecated on mobile, so this Phase 7 keeps the OAuth exchange on the backend rather than embedding credentials in Flutter.
