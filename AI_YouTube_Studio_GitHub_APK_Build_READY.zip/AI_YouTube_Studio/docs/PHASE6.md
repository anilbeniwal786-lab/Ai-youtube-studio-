# Phase 6 — Video Animation + Audio + YouTube

## Added
- Generic real image-to-video REST adapter (`video_provider.py`).
- FFmpeg audio mixing utility for narration/music/SFX.
- Server-side Google OAuth YouTube uploader.
- Project metadata is passed directly to YouTube.
- Shorts 9:16 and long-form 16:9 remain supported.

## Real-provider note
There is intentionally no fake claim that one specific image-to-video vendor is universally available. Put the chosen provider's endpoint/token in `VIDEO_API_URL` and `VIDEO_API_TOKEN`, or implement its adapter in `video_provider.py`.

## YouTube
The uploader uses OAuth and `videos.insert`. For new/unverified API projects, YouTube can restrict uploaded videos to private until the project passes the required audit.

## Security
Keep OpenAI/video/Google credentials only on the backend. Never ship them inside the Flutter APK.
