# Phase 8 — One-Click Production & Publishing Control

Phase 8 builds on Phase 7.

## Added
- One-click backend pipeline: scene images + Hindi TTS + thumbnail + FFmpeg render.
- Background job progress for the full pipeline.
- Editable YouTube title, description and tags endpoint.
- YouTube configuration/authorization status endpoint.
- Flutter button for one-click complete video generation.
- Metadata save action before publishing.

## API
- `POST /api/pipeline`
- `PATCH /api/project/{pid}/metadata`
- `GET /api/youtube/status`
- Existing Phase 7 endpoints remain available.

## Important
The image-to-video provider remains an adapter from Phase 6/7. This phase does not invent a vendor or API key. AI generation requires your own credentials. YouTube publishing requires Google OAuth configuration.
