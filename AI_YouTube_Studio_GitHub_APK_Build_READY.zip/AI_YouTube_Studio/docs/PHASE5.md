# Phase 5

## What is now real
1. Story/scene planning through OpenAI Responses API when `MOCK_MODE=false`.
2. Image generation through the OpenAI image model when configured.
3. Hindi narration through OpenAI TTS when configured.
4. Scene asset manifest.
5. FFmpeg slideshow rendering with gentle zoom/camera movement.
6. 9:16 and 16:9 output.
7. Async job progress.

## What still needs provider-specific work
- True generative image-to-video clips are not universally exposed by the same API. `video` is intentionally an adapter slot so a chosen video provider can be added without changing the app UI.
- Background music and SFX are currently hooks/metadata, not generated audio tracks.
- YouTube OAuth/upload should be completed with your Google Cloud project and secure token storage.

## Security
Never put API keys in Flutter. Keep provider keys on the backend. Use HTTPS and secure token storage in production.
