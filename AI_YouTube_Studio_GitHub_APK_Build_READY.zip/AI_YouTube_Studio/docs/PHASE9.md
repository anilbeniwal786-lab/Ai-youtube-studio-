# Phase 9 — Animation, Audio, Captions & Publishing

Added:
- Automatic SRT Hindi captions from scene narration/timing.
- Optional burned-in captions during FFmpeg render (`BURN_CAPTIONS=true`).
- Background music/SFX pipeline hooks with mock tones for end-to-end testing.
- YouTube caption upload after video upload.
- Caption file endpoint.
- One-click pipeline now produces video + thumbnail + captions.

The image-to-video REST provider remains intentionally configurable; no vendor API is invented. Set `VIDEO_API_URL`/token and implement provider-specific polling as needed.

YouTube supports `captions.insert` for caption tracks and `thumbnails.set` for thumbnails. `videos.insert` uploads the video and metadata.
