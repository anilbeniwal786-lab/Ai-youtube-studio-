# AI YouTube Studio — Mobile APK Builder

यह प्रोजेक्ट फोन से GitHub पर डालकर APK बनाने के लिए तैयार है।

## GitHub Actions
1. इस पूरे `AI_YouTube_Studio` फ़ोल्डर को GitHub repository की root में upload करें।
2. `Actions` खोलें और **Build Android APK** चुनें।
3. **Run workflow** दबाएँ।
4. Build पूरा होने पर workflow के **Artifacts** में `AI-YouTube-Studio-APK` से APK डाउनलोड करें।

Workflow build के दौरान Android platform files अपने-आप generate करता है, इसलिए ZIP में Android Studio project की भारी generated files रखने की जरूरत नहीं है।
