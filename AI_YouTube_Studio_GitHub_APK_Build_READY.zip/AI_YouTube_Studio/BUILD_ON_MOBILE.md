# Mobile-only APK build

1. Create a GitHub account and a new repository.
2. Upload the contents of this ZIP (not the ZIP itself) to the repository.
3. Open the repository > Actions > Build Android APK > Run workflow.
4. Wait for the green check.
5. Open the workflow run > Artifacts > AI-YouTube-Studio-APK and download the ZIP.
6. Extract it and install app-release.apk on your Android phone.

The workflow uses GitHub-hosted Ubuntu and Flutter stable; no PC is required on your side.

Note: this builds the Flutter APK. The AI/backend services still need to be configured separately for real AI generation and YouTube upload.
