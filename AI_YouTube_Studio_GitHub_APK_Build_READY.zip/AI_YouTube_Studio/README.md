# AI YouTube Studio — Phase 9

Phase 9 adds captions, audio finishing, and stronger YouTube publishing.

Flow: Story → scene images → Hindi TTS → SRT captions → optional burned captions → music/SFX mix → thumbnail → YouTube video + thumbnail + Hindi captions.

Start backend from `backend/`: `uvicorn main:app --reload --host 0.0.0.0 --port 8000`.
